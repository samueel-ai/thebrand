/**
 * SPACEBOIS E-Commerce Backend
 * Node.js + Express + MongoDB
 * 
 * Main server file with all routes and middleware
 */

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');

// Load environment variables
dotenv.config();

const app = express();

const emailTransporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: parseInt(process.env.EMAIL_PORT, 10) || 587,
    secure: process.env.EMAIL_SECURE === 'true',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

const emailFrom = process.env.EMAIL_FROM || process.env.EMAIL_USER || 'no-reply@spacebois.com';
const adminNotificationEmail = process.env.ADMIN_NOTIFICATION_EMAIL || process.env.ADMIN_EMAIL || 'admin@spacebois.com';

async function sendOrderNotificationEmails(order) {
    if (!order) return;

    let customerEmail = null;

    if (order.shippingAddress && order.shippingAddress.email) {
        customerEmail = order.shippingAddress.email;
    } else if (order.userId) {
        const user = await User.findById(order.userId);
        if (user && user.email) {
            customerEmail = user.email;
        }
    }

    if (!customerEmail) return;

    const itemsHtml = order.items.map(item => `
        <li>${item.name} x${item.quantity} — ₦${(item.price * item.quantity).toLocaleString()}</li>
    `).join('');

    const orderDetailsText = `Order Number: ${order.orderNumber}\nDelivery: ${order.deliveryOption || 'standard'}\nShipping: ₦${(order.shippingCost || 0).toLocaleString()}\nTotal: ₦${(order.total || 0).toLocaleString()}\n`;

    const customerMail = {
            from: emailFrom,
            to: customerEmail,
            subject: `Your SPACEBOIS order ${order.orderNumber} is confirmed`,
            text: `Thank you for your purchase!\n\n${orderDetailsText}\nItems:\n${order.items.map(item => `${item.name} x${item.quantity} — ₦${(item.price * item.quantity).toLocaleString()}`).join('\n')}\n\nWe will notify you once your order ships.`,
        html: `
            <h2>Thank you for your order!</h2>
            <p>Your order <strong>${order.orderNumber}</strong> has been confirmed.</p>
            <p><strong>Delivery:</strong> ${order.deliveryOption || 'standard'}</p>
            <ul>${itemsHtml}</ul>
            <p><strong>Shipping:</strong> ₦${(order.shippingCost || 0).toLocaleString()}</p>
            <p><strong>Total:</strong> ₦${(order.total || 0).toLocaleString()}</p>
            <p>We will notify you when your order ships.</p>
        `
    };

    const adminMail = {
        from: emailFrom,
        to: adminNotificationEmail,
        subject: `New SPACEBOIS order received: ${order.orderNumber}`,
        text: `New order received:\n\n${orderDetailsText}\nCustomer: ${customerEmail}\n\nItems:\n${order.items.map(item => `${item.name} x${item.quantity} — ₦${(item.price * item.quantity).toLocaleString()}`).join('\n')}
`,
        html: `
            <h2>New order received</h2>
            <p><strong>Order Number:</strong> ${order.orderNumber}</p>
            <p><strong>Customer:</strong> ${customerEmail}</p>
            <p><strong>Delivery:</strong> ${order.deliveryOption || 'standard'}</p>
            <ul>${itemsHtml}</ul>
            <p><strong>Shipping:</strong> ₦${(order.shippingCost || 0).toLocaleString()}</p>
            <p><strong>Total:</strong> ₦${(order.total || 0).toLocaleString()}</p>
        `
    };

    await Promise.allSettled([
        emailTransporter.sendMail(customerMail),
        emailTransporter.sendMail(adminMail)
    ]);
}

// ===== MIDDLEWARE =====
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ===== DATABASE CONNECTION =====
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/spacebois', {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    })
    .then(() => console.log('✓ MongoDB connected'))
    .catch(err => console.error('✗ MongoDB connection error:', err));

// ===== MODELS =====

// User Model
const userSchema = new mongoose.Schema({
    name: String,
    email: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    phone: String,
    profileImage: String,
    addresses: [{
        name: String,
        street: String,
        city: String,
        state: String,
        postalCode: String,
        isDefault: Boolean,
        createdAt: { type: Date, default: Date.now }
    }],
    wishlist: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }],
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

// Product Model
const productSchema = new mongoose.Schema({
    name: String,
    sku: { type: String, unique: true },
    brand: String,
    category: String,
    description: String,
    price: Number,
    images: [String],
    colors: {
        type: Map,
        of: String
    },
    sizes: [String],
    inventory: mongoose.Schema.Types.Mixed,
    rating: Number,
    reviews: { type: Number, default: 0 },
    tags: [String],
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

// Review Model
const reviewSchema = new mongoose.Schema({
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    rating: { type: Number, min: 1, max: 5, required: true },
    title: String,
    comment: String,
    verified: Boolean,
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

// Order Model
const orderSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    orderNumber: { type: String, unique: true },
    items: [{
        productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
        name: String,
        price: Number,
        color: String,
        size: String,
        quantity: Number
    }],
    subtotal: Number,
    shippingCost: Number,
    total: Number,
    status: { type: String, enum: ['pending', 'processing', 'shipped', 'delivered', 'cancelled'], default: 'pending' },
    paymentMethod: String,
    paymentStatus: { type: String, enum: ['pending', 'completed', 'failed'], default: 'pending' },
    shippingAddress: {
        name: String,
        email: String,
        phone: String,
        street: String,
        city: String,
        state: String,
        postalCode: String
    },
    deliveryOption: String,
    trackingNumber: String,
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

// Payment Model
const paymentSchema = new mongoose.Schema({
    orderId: { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    amount: Number,
    currency: { type: String, default: 'NGN' },
    provider: { type: String, enum: ['paystack'], default: 'paystack' },
    status: { type: String, enum: ['pending', 'completed', 'failed'], default: 'pending' },
    transactionId: String,
    reference: String,
    createdAt: { type: Date, default: Date.now }
});

// Create models
const User = mongoose.model('User', userSchema);
const Product = mongoose.model('Product', productSchema);
const Review = mongoose.model('Review', reviewSchema);
const Order = mongoose.model('Order', orderSchema);
const Payment = mongoose.model('Payment', paymentSchema);

// ===== AUTHENTICATION MIDDLEWARE =====
const authenticate = (req, res, next) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        if (!token) return res.status(401).json({ error: 'No token provided' });

        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret');
        req.userId = decoded.userId;
        next();
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
};

// ===== USER ROUTES =====

// Register
app.post('/api/auth/register', async(req, res) => {
    try {
        const { name, email, password } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({ error: 'All fields required' });
        }

        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ error: 'Email already registered' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({
            name,
            email,
            password: hashedPassword
        });

        await user.save();

        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET || 'secret', { expiresIn: '7d' });

        res.json({
            message: 'User registered successfully',
            user: { id: user._id, name: user.name, email: user.email },
            token
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Login
app.post('/api/auth/login', async(req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password required' });
        }

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ error: 'User not found' });
        }

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(400).json({ error: 'Invalid password' });
        }

        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET || 'secret', { expiresIn: '7d' });

        res.json({
            message: 'Login successful',
            user: { id: user._id, name: user.name, email: user.email },
            token
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get User Profile
app.get('/api/users/profile', authenticate, async(req, res) => {
    try {
        const user = await User.findById(req.userId).select('-password');
        res.json(user);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update User Profile
app.put('/api/users/profile', authenticate, async(req, res) => {
    try {
        const { name, phone, bio } = req.body;
        const user = await User.findByIdAndUpdate(
            req.userId, { name, phone, updatedAt: Date.now() }, { new: true }
        ).select('-password');
        res.json(user);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Add Address
app.post('/api/users/addresses', authenticate, async(req, res) => {
    try {
        const { name, street, city, state, postalCode, isDefault } = req.body;
        const user = await User.findById(req.userId);

        if (isDefault) {
            user.addresses.forEach(addr => addr.isDefault = false);
        }

        user.addresses.push({
            name,
            street,
            city,
            state,
            postalCode,
            isDefault: isDefault || user.addresses.length === 0
        });

        await user.save();
        res.json(user.addresses);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get Addresses
app.get('/api/users/addresses', authenticate, async(req, res) => {
    try {
        const user = await User.findById(req.userId);
        res.json(user.addresses);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ===== PRODUCT ROUTES =====

// Get All Products
app.get('/api/products', async(req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get Product by ID
app.get('/api/products/:id', async(req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json(product);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Create Product (Admin only)
app.post('/api/products', authenticate, async(req, res) => {
    try {
        const { name, sku, brand, category, description, price, colors, sizes } = req.body;

        const product = new Product({
            name,
            sku,
            brand,
            category,
            description,
            price,
            colors,
            sizes
        });

        await product.save();
        res.status(201).json(product);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update Product Inventory (Admin only)
app.put('/api/products/:id/inventory', authenticate, async(req, res) => {
    try {
        const { inventory } = req.body;
        const product = await Product.findByIdAndUpdate(
            req.params.id, { inventory, updatedAt: Date.now() }, { new: true }
        );
        res.json(product);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ===== REVIEW ROUTES =====

// Get Product Reviews
app.get('/api/products/:productId/reviews', async(req, res) => {
    try {
        const reviews = await Review.find({ productId: req.params.productId })
            .populate('userId', 'name')
            .sort({ createdAt: -1 });
        res.json(reviews);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Add Review
app.post('/api/reviews', authenticate, async(req, res) => {
    try {
        const { productId, rating, title, comment } = req.body;

        const review = new Review({
            productId,
            userId: req.userId,
            rating,
            title,
            comment,
            verified: true
        });

        await review.save();

        // Update product rating
        const reviews = await Review.find({ productId });
        const avgRating = reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;
        await Product.findByIdAndUpdate(productId, { rating: avgRating, reviews: reviews.length });

        res.status(201).json(review);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ===== ORDER ROUTES =====

// Create Order
app.post('/api/orders', authenticate, async(req, res) => {
    try {
        const { items, shippingAddress, deliveryOption = 'standard', shippingCost, paymentMethod = 'card' } = req.body;
        const shippingCostValue = typeof shippingCost === 'number'
            ? shippingCost
            : deliveryOption === 'express'
            ? 2500
            : deliveryOption === 'free'
            ? 0
            : 1500;

        // Calculate totals
        const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const total = subtotal + shippingCostValue;

        // Generate order number
        const orderNumber = 'ORD-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);

        const order = new Order({
            userId: req.userId,
            orderNumber,
            items,
            subtotal,
            shippingCost: shippingCostValue,
            total,
            shippingAddress,
            deliveryOption,
            paymentMethod,
            status: 'pending',
            paymentStatus: 'pending'
        });

        await order.save();
        res.status(201).json(order);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get User Orders
app.get('/api/orders', authenticate, async(req, res) => {
    try {
        const orders = await Order.find({ userId: req.userId })
            .populate('items.productId')
            .sort({ createdAt: -1 });
        res.json(orders);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get Order by ID
app.get('/api/orders/:id', authenticate, async(req, res) => {
    try {
        const order = await Order.findById(req.params.id)
            .populate('items.productId');

        if (!order) {
            return res.status(404).json({ error: 'Order not found' });
        }

        // Check authorization
        if (order.userId.toString() !== req.userId) {
            return res.status(403).json({ error: 'Not authorized' });
        }

        res.json(order);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ===== PAYMENT ROUTES =====

// Paystack Webhook
app.post('/api/payments/paystack/webhook', async(req, res) => {
    try {
        const { event, data } = req.body;

        if (event === 'charge.success') {
            const reference = data.reference;
            const payment = await Payment.findOne({ reference });

            if (payment && payment.status !== 'completed') {
                payment.status = 'completed';
                payment.transactionId = data.id;
                await payment.save();

                // Update order status
                const order = await Order.findById(payment.orderId);
                if (order) {
                    order.paymentStatus = 'completed';
                    order.status = 'processing';
                    await order.save();
                    sendOrderNotificationEmails(order).catch(err => console.error('Order email failed:', err));
                }
            }
        }

        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Flutterwave Webhook removed - using Paystack only

// Initialize Payment (Paystack)
app.post('/api/payments/initialize', authenticate, async(req, res) => {
    try {
        const { orderId } = req.body;

        const order = await Order.findById(orderId);
        if (!order) {
            return res.status(404).json({ error: 'Order not found' });
        }

        const reference = 'SPACEBOIS-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);

        const payment = new Payment({
            orderId,
            userId: req.userId,
            amount: order.total,
            provider: 'paystack',
            reference
        });

        await payment.save();

        // Return Paystack payment details
        res.json({
            reference,
            amount: order.total,
            email: (await User.findById(req.userId)).email,
            publicKey: process.env.PAYSTACK_PUBLIC_KEY
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ===== WISHLIST ROUTES =====

// Add to Wishlist
app.post('/api/wishlist/:productId', authenticate, async(req, res) => {
    try {
        const user = await User.findById(req.userId);

        if (!user.wishlist.includes(req.params.productId)) {
            user.wishlist.push(req.params.productId);
            await user.save();
        }

        res.json(user.wishlist);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Remove from Wishlist
app.delete('/api/wishlist/:productId', authenticate, async(req, res) => {
    try {
        const user = await User.findById(req.userId);
        user.wishlist = user.wishlist.filter(id => id.toString() !== req.params.productId);
        await user.save();

        res.json(user.wishlist);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get Wishlist
app.get('/api/wishlist', authenticate, async(req, res) => {
    try {
        const user = await User.findById(req.userId).populate('wishlist');
        res.json(user.wishlist);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ===== ADMIN ROUTES =====

// Get All Orders (Admin)
app.get('/api/admin/orders', authenticate, async(req, res) => {
    try {
        const orders = await Order.find()
            .populate('userId', 'name email')
            .populate('items.productId')
            .sort({ createdAt: -1 });
        res.json(orders);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get All Customers (Admin)
app.get('/api/admin/customers', authenticate, async(req, res) => {
    try {
        const customers = await User.aggregate([{
                $lookup: {
                    from: 'orders',
                    localField: '_id',
                    foreignField: 'userId',
                    as: 'orders'
                }
            },
            {
                $project: {
                    name: 1,
                    email: 1,
                    phone: 1,
                    createdAt: 1,
                    ordersCount: { $size: '$orders' }
                }
            },
            { $sort: { createdAt: -1 } }
        ]);
        res.json(customers);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get Dashboard Statistics
app.get('/api/admin/stats', authenticate, async(req, res) => {
    try {
        const totalOrders = await Order.countDocuments();
        const totalRevenue = await Order.aggregate([
            { $match: { paymentStatus: 'completed' } },
            { $group: { _id: null, total: { $sum: '$total' } } }
        ]);

        const totalUsers = await User.countDocuments();
        const totalProducts = await Product.countDocuments();

        res.json({
            totalOrders,
            totalRevenue: totalRevenue[0]?.total || 0,
            totalUsers,
            totalProducts
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ===== ERROR HANDLING =====
app.use((error, req, res, next) => {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
});

// ===== START SERVER =====
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`✓ SPACEBOIS Backend running on port ${PORT}`);
});

module.exports = app;