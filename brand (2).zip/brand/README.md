# 🚀 SPACEBOIS - Complete E-Commerce Platform

A modern, production-ready e-commerce platform built with **Wazaa The Brand × Tabitah** collaboration. Featuring a stunning futuristic streetwear aesthetic, complete shopping experience, and powerful admin dashboard.

## 📋 Features

### ✅ Frontend Features
- **Product Catalog** - Browse products with advanced filtering
- **Product Details** - Image galleries, color/size variants, inventory tracking
- **Shopping Cart** - Add, remove, quantity management with local storage persistence
- **Wishlist** - Save favorite products
- **Advanced Search & Filters** - Category, color, size, price range, sorting
- **User Accounts** - Registration, login, profile management, order history
- **Checkout Flow** - Multi-step checkout with delivery options
- **Reviews & Ratings** - Star ratings, verified purchases, average ratings
- **Responsive Design** - Mobile, tablet, desktop optimized
- **Real-time Toast Notifications** - User feedback for all actions

### ✅ Backend Features
- **User Management** - Registration, authentication, profile updates
- **Product Management** - Full CRUD operations with inventory tracking
- **Order System** - Order creation, tracking, status management
- **Payment Integration** - Paystack & Flutterwave support (card, bank, USSD)
- **Reviews System** - Product reviews with ratings
- **Wishlist** - User wishlist management
- **Admin Dashboard** - Orders, products, inventory, customers, analytics

### ✅ Security
- JWT Authentication
- Password hashing with bcrypt
- CORS protection
- Input validation
- Protected admin routes

## 📁 Project Structure

```
brand/
├── frontend/
│   ├── index.html          # Main application
│   ├── styles.css          # All styles
│   ├── app.js              # Complete app logic
│   └── package.json
├── backend/
│   ├── server.js           # Express server with all routes
│   ├── package.json        # Dependencies
│   ├── .env.example        # Environment template
│   ├── vercel.json         # Vercel deployment config
│   ├── models/             # MongoDB models
│   ├── controllers/        # Route controllers
│   ├── middleware/         # Auth & validation middleware
│   ├── routes/             # API routes
│   └── utils/              # Helper utilities
├── admin/
│   └── index.html          # Admin dashboard
├── config/
│   └── .env                # Environment variables (create this)
└── README.md               # This file
```

## 🛠️ Installation & Setup

### Prerequisites
- Node.js 16+ ([Download](https://nodejs.org/))
- MongoDB 5+ ([Download](https://www.mongodb.com/try/download/community) or use MongoDB Atlas)
- Git

### Backend Setup

1. **Navigate to backend folder:**
   ```bash
   cd backend
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Create `.env` file:**
   ```bash
   cp .env.example .env
   ```

4. **Configure environment variables** in `.env`:
   ```env
   MONGODB_URI=mongodb://localhost:27017/spacebois
   PORT=5000
   NODE_ENV=development
   JWT_SECRET=your_super_secret_jwt_key_here
   
   # Paystack
   PAYSTACK_SECRET_KEY=sk_test_your_paystack_key
   PAYSTACK_PUBLIC_KEY=pk_test_your_paystack_key
   
   # Flutterwave
   FLUTTERWAVE_SECRET_KEY=FLWSECK_TEST-your_key
   FLUTTERWAVE_PUBLIC_KEY=FLWPUBK_TEST-your_key
   ```

5. **Start MongoDB:**
   ```bash
   # macOS with Homebrew
   brew services start mongodb-community
   
   # Linux with systemd
   sudo systemctl start mongod
   
   # Windows (if installed as service)
   net start MongoDB
   
   # Or using Docker
   docker run -d -p 27017:27017 --name mongodb mongo
   ```

6. **Start backend server:**
   ```bash
   npm run dev      # Development with auto-reload
   npm start        # Production
   ```

   Backend will run on: **http://localhost:5000**

### Frontend Setup

1. **Navigate to frontend folder:**
   ```bash
   cd frontend
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Start frontend server:**
   ```bash
   npm run dev
   ```

   Frontend will run on: **http://localhost:3000**

4. **Access the application:**
   - Main store: http://localhost:3000
   - Admin dashboard: http://localhost:3000/admin

## 🔐 Authentication

### Test Credentials
```
Email: test@spacebois.com
Password: test1234
```

### User Registration
Users can create accounts directly through the registration page.

### Admin Access
Contact support to get admin credentials for the admin dashboard.

## 💳 Payment Methods

### Paystack Integration
- **Test Card:** 4084 0843 0843 0847
- **Expiry:** Any future date
- **CVV:** Any 3 digits

### Flutterwave Integration
- Test credentials available on Flutterwave dashboard

## 📡 API Endpoints

### Authentication
```
POST   /api/auth/register              # Register user
POST   /api/auth/login                 # Login user
```

### Products
```
GET    /api/products                   # Get all products
GET    /api/products/:id               # Get single product
POST   /api/products                   # Create product (admin)
PUT    /api/products/:id/inventory     # Update inventory (admin)
```

### Orders
```
POST   /api/orders                     # Create order
GET    /api/orders                     # Get user's orders
GET    /api/orders/:id                 # Get order details
GET    /api/admin/orders               # Get all orders (admin)
```

### Reviews
```
GET    /api/products/:productId/reviews      # Get reviews
POST   /api/reviews                          # Add review
```

### Wishlist
```
POST   /api/wishlist/:productId              # Add to wishlist
DELETE /api/wishlist/:productId              # Remove from wishlist
GET    /api/wishlist                         # Get wishlist
```

### User
```
GET    /api/users/profile                    # Get profile
PUT    /api/users/profile                    # Update profile
GET    /api/users/addresses                  # Get addresses
POST   /api/users/addresses                  # Add address
```

### Admin
```
GET    /api/admin/stats                      # Get dashboard stats
GET    /api/admin/orders                     # Get all orders
```

## 🚀 Deployment

### Deploy Frontend on Vercel

1. **Push to GitHub:**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Connect to Vercel:**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Import your GitHub repository
   - Select `frontend` as root directory
   - Deploy

3. **Frontend URL:** `https://your-domain.vercel.app`

### Deploy Backend on Render

1. **Push to GitHub:**
   ```bash
   git add .
   git commit -m "Backend deployment"
   git push origin main
   ```

2. **Connect to Render:**
   - Go to [render.com](https://render.com)
   - Click "New +"
   - Select "Web Service"
   - Connect your GitHub repository
   - Select `backend` as root directory
   - Set environment variables from `.env`
   - Deploy

3. **Backend URL:** `https://your-service-name.onrender.com`

### Set up MongoDB Atlas

1. Create account on [mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas)
2. Create a cluster
3. Get connection string
4. Update `MONGODB_URI` in `.env` on Render

## 📊 Database Models

### User Schema
```javascript
{
  name: String,
  email: String (unique),
  password: String (hashed),
  phone: String,
  addresses: [Address],
  wishlist: [ObjectId],
  createdAt: Date,
  updatedAt: Date
}
```

### Product Schema
```javascript
{
  name: String,
  sku: String (unique),
  brand: String,
  category: String,
  description: String,
  price: Number,
  images: [String],
  colors: Map,
  sizes: [String],
  inventory: Object,
  rating: Number,
  reviews: Number,
  tags: [String]
}
```

### Order Schema
```javascript
{
  userId: ObjectId,
  orderNumber: String (unique),
  items: [OrderItem],
  subtotal: Number,
  shippingCost: Number,
  total: Number,
  status: String,
  paymentStatus: String,
  shippingAddress: Object,
  deliveryOption: String,
  createdAt: Date,
  updatedAt: Date
}
```

## 🎨 Customization

### Brand Colors
Edit color variables in `frontend/styles.css`:
```css
:root {
    --bk: #050508;      /* Background */
    --pu: #7b2fff;      /* Purple */
    --pk: #ff2d7a;      /* Pink */
    --bl: #00d4ff;      /* Blue */
    --wh: #e8e8ff;      /* White */
    --mu: #9999bb;      /* Muted */
    --cd: #0f0f1e;      /* Card Dark */
    --br: #1e1e3f;      /* Border */
}
```

### Products
Edit product data in `frontend/app.js` (products array) or create via admin dashboard.

## 🧪 Testing

### Frontend Testing
```bash
cd frontend
npm test
```

### Backend Testing
```bash
cd backend
npm test
```

## 📝 Environment Variables Checklist

- [ ] `MONGODB_URI` - MongoDB connection string
- [ ] `JWT_SECRET` - Secure random string
- [ ] `PAYSTACK_SECRET_KEY` - From Paystack dashboard
- [ ] `PAYSTACK_PUBLIC_KEY` - From Paystack dashboard
- [ ] `FLUTTERWAVE_SECRET_KEY` - From Flutterwave dashboard
- [ ] `FLUTTERWAVE_PUBLIC_KEY` - From Flutterwave dashboard
- [ ] `NODE_ENV` - "production" for deployed
- [ ] `PORT` - 5000 for development
- [ ] `FRONTEND_URL` - Frontend deployment URL

## 🐛 Troubleshooting

### MongoDB Connection Error
- Ensure MongoDB is running: `mongod` or check Docker container
- Verify `MONGODB_URI` in `.env`
- For Atlas: Check IP whitelist

### CORS Error
- Backend and frontend must have matching protocol (http/https)
- Check CORS configuration in `server.js`

### Payment Not Working
- Verify API keys are correct
- Check test/live mode in payment provider dashboards
- Ensure webhook URLs are configured

### Port Already in Use
```bash
# Kill process on port 5000
lsof -ti:5000 | xargs kill -9

# Or use different port
PORT=5001 npm run dev
```

## 📈 Performance Optimization

1. **Frontend:**
   - Lazy load images
   - Minimize CSS/JS
   - Use service workers for caching

2. **Backend:**
   - Add database indexes on frequently queried fields
   - Implement pagination for large data sets
   - Use Redis for caching

3. **Deployment:**
   - Enable gzip compression
   - Use CDN for static assets
   - Implement rate limiting

## 🔄 Updates & Maintenance

### Regular Tasks
- Monitor error logs
- Update dependencies: `npm audit fix`
- Back up database regularly
- Review and optimize slow queries

## 📚 Additional Resources

- [Express.js Documentation](https://expressjs.com/)
- [MongoDB Documentation](https://docs.mongodb.com/)
- [Paystack API Documentation](https://paystack.com/docs/api/)
- [Flutterwave API Documentation](https://developer.flutterwave.com/)
- [Vercel Deployment Guide](https://vercel.com/docs)
- [Render Deployment Guide](https://render.com/docs)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see LICENSE file for details.

## 💬 Support

For support and inquiries:
- Email: support@spacebois.com
- Issues: Create GitHub issues
- Discord: [Join our community](https://discord.gg/spacebois)

## 🎯 Roadmap

- [ ] Mobile apps (React Native)
- [ ] Analytics dashboard improvements
- [ ] Multi-vendor marketplace
- [ ] AI-powered recommendations
- [ ] Live chat support
- [ ] Social media integration
- [ ] Subscription boxes

---

**Made with ❤️ for SPACEBOIS** | © 2025 SPACEBOIS. All Rights Reserved.
