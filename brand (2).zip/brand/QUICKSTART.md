# SPACEBOIS - Quick Start Guide

## 🚀 5-Minute Setup

### Step 1: Clone/Download Project
```bash
cd brand
```

### Step 2: Start MongoDB

**Option A: Local MongoDB**
```bash
mongod
```

**Option B: Docker**
```bash
docker run -d -p 27017:27017 --name mongodb mongo
```

**Option C: MongoDB Atlas (Cloud)**
- Create account at mongodb.com/cloud/atlas
- Create a cluster and get connection string
- Use it as MONGODB_URI in .env

### Step 3: Backend Setup
```bash
cd backend
npm install
cp .env.example .env

# Edit .env with your details
# Most importantly: MONGODB_URI

npm run dev
```

Backend runs on: **http://localhost:5000**

### Step 4: Frontend Setup (New Terminal)
```bash
cd frontend
npm install
npm run dev
```

Frontend runs on: **http://localhost:3000**

### Step 5: Test the App
1. Open http://localhost:3000 in browser
2. Browse products
3. Register account
4. Add items to cart
5. Checkout (test with card: 4084 0843 0843 0847)

## 📊 Admin Dashboard

Access at: **http://localhost:3000/admin**

**Default Credentials:**
- Email: admin@spacebois.com
- Password: admin123

> ⚠️ Change these credentials in production!

## 🔑 Environment Setup

Create `backend/.env`:
```env
# Database
MONGODB_URI=mongodb://localhost:27017/spacebois

# Server
PORT=5000
NODE_ENV=development

# JWT
JWT_SECRET=super_secret_key_change_this_in_production

# Paystack (get from https://paystack.com)
PAYSTACK_SECRET_KEY=sk_test_your_key
PAYSTACK_PUBLIC_KEY=pk_test_your_key

# Flutterwave (get from https://flutterwave.com)
FLUTTERWAVE_SECRET_KEY=FLWSECK_TEST-your_key
FLUTTERWAVE_PUBLIC_KEY=FLWPUBK_TEST-your_key
```

## 🧪 Test Credentials

### Create Test Account
- Email: `test@spacebois.com`
- Password: `Test@123`

### Test Payment Card (Paystack)
- Card: `4084 0843 0843 0847`
- Expiry: `12/99`
- CVV: `999`

## 📱 Features to Try

1. **Browse Products**
   - Filter by category, brand, color, size, price
   - Sort by newest, price, popularity

2. **Product Details**
   - View multiple images
   - Select color & size
   - Check inventory
   - Add reviews & ratings

3. **Shopping Cart**
   - Add/remove products
   - Adjust quantities
   - Cart persists on page refresh

4. **Wishlist**
   - Save favorite items
   - Access from sidebar

5. **Checkout**
   - Multi-step form
   - Select delivery option
   - Choose payment method
   - Complete order

6. **Account**
   - User profile management
   - Order history
   - Saved addresses

## 🛠️ Common Issues

### "Cannot find module" Error
```bash
cd backend
npm install
```

### "Port 5000 already in use"
```bash
# Kill process
lsof -ti:5000 | xargs kill -9

# Or use different port
PORT=5001 npm run dev
```

### MongoDB Connection Failed
1. Ensure MongoDB is running
2. Check MONGODB_URI in .env
3. For Atlas: Add IP to whitelist

### Payment Not Working
1. Get real API keys from Paystack/Flutterwave
2. Add to .env file
3. Restart backend: `npm run dev`

## 📦 NPM Commands

### Backend
```bash
npm install          # Install dependencies
npm run dev          # Development mode with auto-reload
npm start            # Production mode
npm test             # Run tests
```

### Frontend
```bash
npm install          # Install dependencies
npm run dev          # Start development server
npm run build        # Build for production
npm test             # Run tests
```

## 🌐 Deployment

### Vercel (Frontend)
1. Push code to GitHub
2. Connect GitHub account to Vercel
3. Select frontend folder
4. Deploy

### Render (Backend)
1. Push code to GitHub
2. Connect GitHub account to Render
3. Create web service
4. Select backend folder
5. Add environment variables
6. Deploy

### MongoDB Atlas
1. Create account
2. Create cluster
3. Get connection string
4. Add to Render environment variables

## 📞 Support

### Debugging
- Check browser console for frontend errors: `F12`
- Check terminal for backend errors
- Check MongoDB connection: `mongo` command

### Common Commands
```bash
# View MongoDB databases
mongo

# View collections in database
db.products.find()

# Clear cache
npm cache clean --force

# Reinstall everything
rm -rf node_modules package-lock.json
npm install
```

## ✅ Checklist Before Production

- [ ] Change JWT_SECRET to random string
- [ ] Update admin credentials
- [ ] Add real Paystack/Flutterwave keys
- [ ] Enable HTTPS
- [ ] Set NODE_ENV=production
- [ ] Configure CORS for production domain
- [ ] Set up database backups
- [ ] Configure error monitoring (Sentry)
- [ ] Test all payment scenarios
- [ ] Test on mobile devices

## 🎓 Learning Resources

- Express.js: https://expressjs.com/starter/basic-routing.html
- MongoDB: https://docs.mongodb.com/manual/
- JavaScript: https://javascript.info/
- REST API: https://restfulapi.net/

## 📝 Next Steps

1. Customize products in app.js
2. Customize colors in styles.css
3. Add more payment providers
4. Integrate email notifications
5. Add SMS notifications
6. Set up analytics
7. Create mobile app

---

**Ready to start? Run these commands:**

```bash
# Terminal 1: Backend
cd backend && npm install && npm run dev

# Terminal 2: Frontend
cd frontend && npm install && npm run dev
```

Then open http://localhost:3000 in your browser!
