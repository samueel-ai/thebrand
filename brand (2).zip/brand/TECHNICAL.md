# SPACEBOIS Technical Documentation

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      Client Browser                              │
│  (index.html, styles.css, app.js - Vanilla JS)                 │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ HTTPS/AJAX
                         │
┌────────────────────────▼────────────────────────────────────────┐
│                   REST API (Express.js)                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Routes: /api/auth, /api/products, /api/orders, etc.   │  │
│  └──────────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Middleware: JWT Auth, CORS, Validation, Error Handler │  │
│  └──────────────────────────────────────────────────────────┘  │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ MongoDB Protocol
                         │
┌────────────────────────▼────────────────────────────────────────┐
│                  MongoDB Database                                │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Collections: users, products, orders, reviews, payments │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## Technology Stack

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Advanced styling with CSS Grid/Flexbox
- **Vanilla JavaScript** - No frameworks, pure JS
- **Local Storage** - Cart & wishlist persistence

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web framework
- **MongoDB** - NoSQL database
- **JWT** - Authentication tokens
- **bcryptjs** - Password hashing

### Payment Providers
- **Paystack** - Card, bank transfer, USSD
- **Flutterwave** - Multiple payment methods

## Key Features Implementation

### 1. Product Filtering & Search
- Filter by category, brand, color, size, price
- Sort by newest, price, popularity
- Real-time search with debouncing
- Maintains filter state in state object

### 2. Shopping Cart
- Add/remove items with variants
- Quantity management
- Persistent storage in localStorage
- Automatic total calculation with shipping

### 3. User Authentication
- JWT-based authentication
- Secure password hashing with bcrypt
- Protected API routes
- Token expiration (7 days)

### 4. Payment Processing
- Paystack integration for multiple payment methods
- Flutterwave as fallback provider
- Webhook validation for payment confirmation
- Transaction tracking and order status updates

### 5. Admin Dashboard
- Dashboard with key statistics
- Order management and tracking
- Product inventory management
- Customer management
- Sales analytics

## Deployment Strategy

### Frontend (Vercel)
- Automatic deployments from GitHub
- Global CDN distribution
- Automatic HTTPS
- Environment variables support

### Backend (Render)
- Node.js server deployment
- Auto-scaling capability
- Automatic SSL certificates
- Log streaming and monitoring

### Database (MongoDB Atlas)
- Cloud-hosted MongoDB
- Automatic backups
- Vertical & horizontal scaling
- Built-in monitoring

## Security Features

✅ Password hashing with bcrypt  
✅ JWT token-based authentication  
✅ CORS protection  
✅ Input validation on all routes  
✅ Protected admin routes  
✅ Secure payment handling  
✅ Environment variable protection  
✅ HTTPS enforcement in production  

## Performance Optimizations

✅ Lazy loading images  
✅ CSS & JS minification  
✅ Database query optimization  
✅ Caching strategies  
✅ Responsive design  
✅ Pagination support  
✅ Rate limiting ready  

---

For complete setup instructions, see [QUICKSTART.md](QUICKSTART.md)
For deployment guide, see [README.md](README.md)
